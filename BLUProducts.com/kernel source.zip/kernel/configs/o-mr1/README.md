# Android Kernel Config Fragments For Target Framework Compatibility Matrix Version 2

This directory contains requirements for devices with Target FCM Version 2,
which are commonly known as "devices launched with O-MR1".
