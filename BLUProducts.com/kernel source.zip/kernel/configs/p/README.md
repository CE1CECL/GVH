# Android Kernel Config Fragments For Target Framework Compatibility Matrix Version 3

This directory contains requirements for devices with Target FCM Version 3,
which are commonly known as "devices launched with P".
