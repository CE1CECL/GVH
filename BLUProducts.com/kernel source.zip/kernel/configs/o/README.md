# Android Kernel Config Fragments For Target Framework Compatibility Matrix Version 1

This directory contains requirements for devices with Target FCM Version 1,
which are commonly known as "devices launched with O".
